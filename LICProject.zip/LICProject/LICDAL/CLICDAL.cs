﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LICEntities;
using LICExceptions;
using System.Data;
using System.Data.Common;

namespace LICDAL
{
    public class CLICDAL
    {
        public List<Policy> GetPolicyName()
        {
            List<Policy> policyList = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspPopulatePolicy";

                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    policyList = new List<Policy>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        Policy policy = new Policy();
                        policy.PolicyID = (int)dataTable.Rows[rowCounter][0];
                        policy.PolicyName = (string)dataTable.Rows[rowCounter][1];
                        policyList.Add(policy);
                    }
                }
            }
            catch (DbException ex)
            {
                throw new CLICExceptions(ex.Message);
            }
            return policyList;
        }

        public List<Branches> GetBranchName()
        {
            List<Branches> branchesList = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspPopulateBranches";



                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    branchesList = new List<Branches>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        Branches b = new Branches();
                        b.BranchID = (int)dataTable.Rows[rowCounter][0];
                        b.BranchName = (string)dataTable.Rows[rowCounter][1];
                        branchesList.Add(b);
                    }



                }
            }
            catch (DbException ex)
            {
                throw new CLICExceptions(ex.Message);
            }
            return branchesList;
        }
        public bool AddCustomers(Customers cm)
        {
            bool cmAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "insertCustomerDetails";

                //DbParameter param = command.CreateParameter();
                //param.ParameterName = "@custId";
                //param.DbType = DbType.Int32;
                //param.Value = cm.CUSTID;
                //command.Parameters.Add(param);

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_vcCustomerName";
                param.DbType = DbType.String;
                param.Value = cm.CustomerName;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcCustomerDOB";
                param.DbType = DbType.DateTime;
                param.Value = cm.CustomerDOB;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcCustomerAddress";
                param.DbType = DbType.String;
                param.Value = cm.CustomerAddress;
                command.Parameters.Add(param);

                param.ParameterName = "@ipv_iPolicyID";
                param.DbType = DbType.Int32;
                param.Value = cm.PolicyID;
                command.Parameters.Add(param);


                param.ParameterName = "@ipv_iBranchID";
                param.DbType = DbType.Int32;
                param.Value = cm.BranchID;
                command.Parameters.Add(param);


                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    cmAdded = true;
            }
            catch (DbException ex)
            {

                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new CLICExceptions(errormessage);
            }
            return cmAdded;
        }
    }
  }

