﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LICBAL;
using LICEntities;
using LICExceptions;

namespace LICProject
{
    public partial class RegistrationPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LblMessage.Text = "";
            if (!Page.IsPostBack)
            {
                try
                {

                    List<Policy> LICList = CLICBAL.GetPolicyName();
                    //******************Bind Dropdown with Data Source**********
                    DropDownList1.Items.Clear();
                    DropDownList1.Items.Add(new ListItem("Select a Policy", "0"));
                    DropDownList1.AppendDataBoundItems = true;
                    DropDownList1.DataSource = LICList;

                    //******************To populate or to tell what to display*****************
                    DropDownList1.DataTextField = "PolicyName";
                    DropDownList1.DataValueField = "PolicyID";

                    DropDownList1.DataBind();//Binds with current source

                    //*****************************************************


                    List<Branches> BList = CLICBAL.GetBranchName();
                    //******************Bind Dropdown with Data Source**********
                    DropDownList2.Items.Clear();
                    DropDownList2.Items.Add(new ListItem("Select a Branch", "0"));
                    DropDownList2.AppendDataBoundItems = true;
                    DropDownList2.DataSource = BList;

                    //******************To populate or to tell what to display*****************
                    DropDownList2.DataTextField = "BranchName";
                    DropDownList2.DataValueField = "BranchID";

                    DropDownList2.DataBind();//Binds with current source

                    //*****************************************************
                }
                catch
                {

                }
            }



        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            try
            {
                Customers C1 = new Customers();
                C1.CustomerName = tbCustomerName.Text;
                C1.CustomerAddress = tbAddress.Text;
                C1.PolicyID = Convert.ToInt32(DropDownList1.SelectedItem.Value);
                C1.BranchID = Convert.ToInt32(DropDownList2.SelectedItem.Value);
                bool cmAdded = CLICBAL.AddCustomers(C1);
                if (cmAdded)
                {
                    LblMessage.Text = "Customer Added Successfully";

                }

                else
                    LblMessage.Text = "Customer can not be Added";

            }
                catch (CLICExceptions ex)
                {
                    Console.WriteLine(ex.Message);
                }

        }
    }
}