﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LICExceptions;
using LICDAL;
using LICEntities;
namespace LICBAL
{
    public class CLICBAL
    {
        public static List<Policy> GetPolicyName()
        {
            List<Policy> policyList = null;
            try
            {
                CLICDAL P1 = new CLICDAL();
                policyList = P1.GetPolicyName();

            }
            catch (CLICExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return policyList;
        }

        public static List<Branches> GetBranchName()
        {
            List<Branches> branchesList = null;
            try
            {
                CLICDAL b1 = new CLICDAL();
                branchesList = b1.GetBranchName(); 
            }
            catch (CLICExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return branchesList;
        }

        public static bool AddCustomers(Customers newcom)
        {
            bool comAdded = false;
            try
            {
                CLICDAL comDAL = new CLICDAL();
                comAdded = comDAL.AddCustomers(newcom);
            }
            catch (CLICExceptions)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return comAdded;

        }

    }
}
