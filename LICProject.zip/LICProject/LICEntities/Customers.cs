﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LICEntities
{
    public class Customers
    {
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
        public DateTime CustomerDOB { get; set; }
        public string CustomerAddress { get; set; }
        public int PolicyID { get; set; }
        public int BranchID { get; set; }
    }
}
