﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LICEntities
{
    public class Policy
    {
        public int PolicyID { get; set; }
        public string PolicyName { get; set; }
        public int Duration { get; set; }
        public double Premiumamt { get; set; }
        public double Maturityamt { get; set; }
    }
}
