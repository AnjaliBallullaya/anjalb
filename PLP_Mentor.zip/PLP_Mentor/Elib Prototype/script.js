function redirectpage()
{
	if(document.getElementById('txtUserName').value=="karthik" && document.getElementById('txtPassword').value=="karthik")
	window.location.href = "nonsubscriber-home.html";
	else if(document.getElementById('txtUserName').value=="admin" && document.getElementById('txtPassword').value=="admin")
		window.location.href = "admin-home.html";
	else
	{
	clearText();
	}
}
function clearText()
{
	document.getElementById('txtUserName').value="";
	document.getElementById('txtPassword').value="";
}
