﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITY;
using LICDAL;

namespace LICBAL
{
    public class ClassLICBAL
    {

        public static bool SearchCustomer(string LogName, string Password)
        {
            bool CorrectLog = false;

            CorrectLog = ClassLICDAL.SearchCustomer(LogName, Password);

            return CorrectLog;
        }

        public static List<string> GetAllPolicyBAL()
        {
            List<string> PolicyList = null;

            PolicyList = ClassLICDAL.GetAllPolicyDAL();
            return PolicyList;
        }

        public static int GetPolicyID(string PolicyName)
        {
            int PolicyID = 0;
            PolicyID = ClassLICDAL.GetPolicyID(PolicyName);
            return PolicyID;
        }

        public static List<string> GetAllBranchBAL()
        {
            List<string> BranchList = null;

            BranchList = ClassLICDAL.GetAllBranchDAL();
            return BranchList;
        }

        public static int GetBranchID(string BranchName)
        {
            int BranchID = 0;
            BranchID = ClassLICDAL.GetBranchID(BranchName);
            return BranchID;
        }

        public static ClassCustomer GetCustomerInfoBAL(string CustomerName)
        {
           ClassCustomer Customer = new ClassCustomer();
            Customer = ClassLICDAL.GetCustomerInfoDAL(CustomerName);
            return Customer;
        }

        public static bool SearchCustInCSTBAL(ClassCustomerPolicy CS)
        {
            bool Exists=false;
            Exists = ClassLICDAL.SearchCustInCSTDAL(CS);
            return Exists;
        }

       public static bool AddNewCustPolicyBAL(ClassCustomerPolicy CS)
        {
            bool added=false;
            added = ClassLICDAL.AddNewCustPolicyDAL(CS);
            return added;
        }

        public static bool NewRegisterBAL(ClassCustomer NewCustObj)
        {
            bool Registered = false;
            Registered = ClassLICDAL.NewRegisterDAL(NewCustObj);
            return Registered;
        }

        public static int GetNewCustIDBAL(ClassCustomer NewCustObj)
        {
            int CustID= 0;
            CustID = ClassLICDAL.NewCustIDDAL(NewCustObj);
            return CustID;

        }


    }
}
