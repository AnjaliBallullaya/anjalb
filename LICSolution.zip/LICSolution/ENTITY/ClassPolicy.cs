﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITY
{
    class ClassPolicy
    {
        public int PolicyID { get; set; }

        public string PolicyName { get; set; }

        public Int32 Duration { get; set; }

        public decimal PremiumAmount { get; set; }

        public decimal MaturityAmount { get; set; }
        
    }
}
