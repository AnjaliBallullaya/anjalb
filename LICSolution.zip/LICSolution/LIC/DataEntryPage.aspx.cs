﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ENTITY;
using LICBAL;

namespace LIC
{
    public partial class DataEntryPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string CustomerName = Request.QueryString[0];


                DropDownList1.Items.Add(new ListItem("Select a Policy", "0"));
                DropDownList1.AppendDataBoundItems = true;

                List<string> PolicyList = new List<string>();

                PolicyList = ClassLICBAL.GetAllPolicyBAL();

                foreach (string Item in PolicyList)
                {
                    DropDownList1.Items.Add(Item);
                }


                DropDownList2.Items.Add(new ListItem("Select a Branch", "0"));
                DropDownList2.AppendDataBoundItems = true;

                List<string> BranchList = new List<string>();
                BranchList = ClassLICBAL.GetAllBranchBAL();


                foreach (var Item in BranchList)
                {
                    DropDownList2.Items.Add(Item);
                }



                TextBoxCustName.Text = CustomerName.ToString();
                ClassCustomer Customer = new ClassCustomer();
                Customer = ClassLICBAL.GetCustomerInfoBAL(CustomerName);
                TextBoxDOB.Text = Customer.BirthDate.ToString();
                TextBoxCustID.Text = Customer.CustomerID.ToString();
                TextBoxAddress.Text = Customer.CustomerAddress.ToString();
            }
            

        }

        
        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int PolicyID = 0;
            string PolicyName = "";
            PolicyName = DropDownList1.SelectedItem.Text;
            

           PolicyID = ClassLICBAL.GetPolicyID(PolicyName);

            if(PolicyID>0)
            TextBoxPolicyID.Text = PolicyID.ToString();
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int BranchID = 0;
            string BranchName = DropDownList2.SelectedItem.Text;


            BranchID = ClassLICBAL.GetBranchID(BranchName);

            if (BranchID > 0)
                TextBoxBranchID.Text = BranchID.ToString();
        }

        protected void ButtonSubmit_Click(object sender, EventArgs e)
        {
            ClassCustomerPolicy CS = new ClassCustomerPolicy();
            CS.CustomerID = Convert.ToInt32(TextBoxCustID.Text);
            CS.PolicyID= Convert.ToInt32(TextBoxPolicyID.Text);
            CS.BranchID= Convert.ToInt32(TextBoxBranchID.Text);

            bool Exists = false;
            Exists = ClassLICBAL.SearchCustInCSTBAL(CS);

            if(Exists)
            {
                Label9.Text = "The Current Policy already exists with the User";
            }

            else
            {
                bool added = false;
                added=ClassLICBAL.AddNewCustPolicyBAL(CS);
                if(added)
                {
                    Label9.Text = "The Customer is subscribed to the new policy. Congratulations...!!!";
                }
            }


        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            DropDownList1.SelectedIndex = 0;
            TextBoxPolicyID.Text ="" ;

            DropDownList2.SelectedIndex = 0;
            TextBoxBranchID.Text = "";
        }

        //protected void ButtonSubmit_Click(object sender, EventArgs e)
        //{

        //}

        //protected void TextBoxBranchID_TextChanged(object sender, EventArgs e)
        //{

        //}
    }
}