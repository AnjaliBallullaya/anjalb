﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EmployeeMgmtSystemBAL;
using EmployeeMgmtSystemEntities;
using EmployeeMgmtSystemExceptions;

using System.Data.SqlClient;
using System.Data;

namespace WPFEmployeeMgmtSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
     
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ListAllEmployees_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                List<Employee> EmployeeList = EmployeeBAL.GetAllEmployeesBAL();
                dataGrid.ItemsSource = EmployeeList;


            }
            catch (EmployeeMgmtException ex)
            {
                label5.Content = (ex.Message);
            }
        }

        private void SearchEmployeeById_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int EmployeeID = Convert.ToInt32(textBox.Text);
                Employee searchEmployee = EmployeeBAL.SearchEmployeesBAL(EmployeeID);
                if (searchEmployee != null)
                {
                    textBox1.Text = searchEmployee.EmployeeName.ToString();
                    textBox2.Text = searchEmployee.City.ToString();
                    textBox3.Text = searchEmployee.DepartmentName.ToString();
                    doj.Text = searchEmployee.DateofJoin.ToString();

                }
                else
                    MessageBox.Show("Employee with the specified Id not found");
            }
            catch (EmployeeMgmtException ex)
            {
                label5.Content = (ex.Message);
            }
        }

        private void UpdateEmployee_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int updateEmployeeID = Convert.ToInt32(textBox.Text);
                Employee updatedEmployee = EmployeeBAL.SearchEmployeesBAL(updateEmployeeID);
                if (updatedEmployee != null)
                {
                    updatedEmployee.EmployeeName = textBox1.Text;
                    updatedEmployee.City = textBox2.Text;
                    updatedEmployee.DepartmentName = textBox3.Text;
                    DateTime date = Convert.ToDateTime(doj.Text);
                    updatedEmployee.DateofJoin = date;

                    bool employeeUpdated = EmployeeBAL.UpdateEmployeesBAL(updatedEmployee);
                    if (employeeUpdated)
                    {
                        List<Employee> employeeList = EmployeeBAL.GetAllEmployeesBAL();
                        dataGrid.ItemsSource = employeeList;
                        MessageBox.Show("Employee Row Updated");
                    }
                    else
                    {
                        MessageBox.Show("Employee Row not Updated");
                    }

                }
            }
            catch (EmployeeMgmtException ex)
            {
                label5.Content = (ex.Message);
            }
        }

        private void DeleteEmployee_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                MessageBoxResult result = MessageBox.Show("Are u sure you want to delete?", "Delete Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    int deleteEmployeeID = Convert.ToInt32(textBox.Text);
                    Employee deleteEmployee = EmployeeBAL.SearchEmployeesBAL(deleteEmployeeID);
                    if (deleteEmployee != null)
                    {
                        bool employeedeleted = EmployeeBAL.DeleteEmployeesBAL(deleteEmployeeID);
                        if (employeedeleted)
                        {
                            List<Employee> employeeList = EmployeeBAL.GetAllEmployeesBAL();
                            dataGrid.ItemsSource = employeeList;
                            MessageBox.Show("Employee Deleted");
                        }
                        else
                            MessageBox.Show("Employee not Deleted");
                    }
                }
            }
            catch (EmployeeMgmtException ex)
            {
                label5.Content = (ex.Message);
            }
        }

        private void dataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                Employee obj1 = (Employee)dataGrid.CurrentCell.Item;
                textBox.Text = obj1.EmployeeID.ToString();
                textBox1.Text = obj1.EmployeeName;
                textBox2.Text = obj1.City;
                textBox3.Text = obj1.DepartmentName;
                doj.Text = obj1.DateofJoin.ToString();
                //var obj = dataGrid.SelectedItem;//DataRowView dataRow
                //textBox.Text = ((Employee)obj).EmployeeID.ToString();
                //textBox1.Text = ((Employee)obj).EmployeeName.ToString();
                //textBox2.Text = ((Employee)obj).City.ToString();
                //textBox3.Text = ((Employee)obj).DepartmentName.ToString();
                //doj.Text = obj.DateofJoin.ToString();
            }
            catch (EmployeeMgmtException ex)
            {
                label5.Content = (ex.Message);
            }
        }

        private void AddEmployee_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                Employee newEmployee = new Employee();
                // newEmployee.EmployeeID = Convert.ToInt32(textBox.Text);
                newEmployee.EmployeeName = textBox1.Text;
                newEmployee.City = textBox2.Text;
                newEmployee.DepartmentName = textBox3.Text;
                newEmployee.DateofJoin = Convert.ToDateTime(doj.SelectedDate);
                bool employeeAdded = EmployeeBAL.AddEmployeesBAL(newEmployee);
                if (employeeAdded)
                {
                    List<Employee> employeeList = EmployeeBAL.GetAllEmployeesBAL();
                    dataGrid.ItemsSource = employeeList;
                    MessageBox.Show("Employee Added");
                }
                else
                    MessageBox.Show("Employee not Added");
            }
            catch (EmployeeMgmtException ex)
            {
                label5.Content = (ex.Message);
            }
        }
    }
}
