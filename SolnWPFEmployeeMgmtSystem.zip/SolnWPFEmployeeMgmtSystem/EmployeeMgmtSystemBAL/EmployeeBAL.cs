﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeMgmtSystemDAL;
using EmployeeMgmtSystemEntities;
using EmployeeMgmtSystemExceptions;

namespace EmployeeMgmtSystemBAL
{
    public class EmployeeBAL
    {
        private static bool ValidateEmployee(Employee employee)
        {
            StringBuilder sb = new StringBuilder();
            bool validEmployee = true;
           //if (employee.EmployeeID <= 0)
           // { 
           //     validEmployee = false;
           //     sb.Append(Environment.NewLine + "Invalid Employee ID");
           // }

            if (employee.EmployeeName == string.Empty)
            {

                validEmployee = false;
                sb.Append(Environment.NewLine + "Employee Name Required");

            }

            if (employee.City == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "City Required");
            }

            if (employee.DepartmentName == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "DepartmentName Required");
            }
            if (employee.DateofJoin == null)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Date of joining required");
            }

            if (validEmployee == false)
                throw new EmployeeMgmtException(sb.ToString());
            return validEmployee;
        }

        public static bool AddEmployeesBAL(Employee newEmployee)
        {
            bool employeeAdded = false;
            try
            {
                if (ValidateEmployee(newEmployee))
                {
                    EmployeeDAL employeeDAL = new EmployeeDAL();
                    employeeAdded = employeeDAL.AddEmployeesDAL(newEmployee);
                }
            }
            catch (EmployeeMgmtException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employeeAdded;

            //bool employeeAdded = false;
            //try
            //{
            //    if (ValidateEmployee(newEmployee))
            //    {
            //        EmployeeDAL employeeDAL = new EmployeeDAL();
            //        employeeAdded = employeeDAL.AddEmployeesDAL(newEmployee);
            //    }
            //}
            //catch (EmployeeMgmtException)
            //{
            //    throw;
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}

            //return employeeAdded;


        }

        public static List<Employee> GetAllEmployeesBAL()
        {
            List<Employee> employeeList = null;
            try
            {
                EmployeeDAL employeeDAL = new EmployeeDAL();
                employeeList = employeeDAL.GetAllEmployeesDAL();
            }
            catch (EmployeeMgmtException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employeeList;

        }

        public static Employee SearchEmployeesBAL(int searchEmployeeID)
        {
            Employee searchEmployee = null;
            try
            {
                EmployeeDAL employeeDAL = new EmployeeDAL();
                searchEmployee = employeeDAL.SearchEmployeesDAL(searchEmployeeID);

            }
            catch (EmployeeMgmtException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchEmployee;

        }

        public static bool DeleteEmployeesBAL(int deleteEmployeeID)
        {
            bool employeeDeleted = false;
            try
            {
                if (deleteEmployeeID > 0)
                {
                    EmployeeDAL employeeDAL = new EmployeeDAL();
                    employeeDeleted = employeeDAL.DeleteEmployeesDAL(deleteEmployeeID);
                }
                else
                {
                    throw new EmployeeMgmtException("Invalid Employee ID");
                }
            }
            catch (EmployeeMgmtException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employeeDeleted;
        }
        public static bool UpdateEmployeesBAL(Employee updateEmployee)
        {
            bool employeeUpdated = false;
            try
            {
                if (ValidateEmployee(updateEmployee))
                {
                    EmployeeDAL employeeDAL = new EmployeeDAL();
                    employeeUpdated = employeeDAL.UpdateEmployeesDAL(updateEmployee);
                }
            }
            catch (EmployeeMgmtException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employeeUpdated;
        }

    }
}

