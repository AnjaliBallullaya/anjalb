﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeMgmtSystemExceptions
{
    public class EmployeeMgmtException:ApplicationException
    {
        public EmployeeMgmtException()
            : base()
        {
        }

        public EmployeeMgmtException(string message)
            : base(message)
        {
        }
        public EmployeeMgmtException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
