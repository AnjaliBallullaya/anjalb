﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeMgmtSystemEntities;
using EmployeeMgmtSystemExceptions;
using System.Data;
using System.Data.Common;

namespace EmployeeMgmtSystemDAL
{
    public class EmployeeDAL
    {
        public List<Employee> GetAllEmployeesDAL()
        { 
            List<Employee> employeeList = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "ProGetAllEmployee1";



                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    employeeList = new List<Employee>();
                    for (int rowCounter = 0; rowCounter<dataTable.Rows.Count; rowCounter++)
                    {
                        Employee employee = new Employee();
                        employee.EmployeeID = (int)dataTable.Rows[rowCounter][0];
                        employee.EmployeeName = (string)dataTable.Rows[rowCounter][1];
                        employee.City = (string)dataTable.Rows[rowCounter][2];
                        employee.DepartmentName = (string)dataTable.Rows[rowCounter][3];
                        employee.DateofJoin = (DateTime)dataTable.Rows[rowCounter][4];
                        employeeList.Add(employee);
                    }
                }
            }
            catch (DbException ex)
            {
                throw new EmployeeMgmtException(ex.Message);
            }
            return employeeList;
        }

 

    public bool AddEmployeesDAL(Employee newEmployee)
    {
            bool employeeAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "ProAddEmployee1";

                DbParameter param = command.CreateParameter();
                //param.ParameterName = "@iEmployeeID";
                //param.DbType = DbType.Int32;
                //param.Value = newEmployee.EmployeeID;
                //command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@vcEmployeeName";
                param.DbType = DbType.String;
                param.Value = newEmployee.EmployeeName;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@vcCity";
                param.DbType = DbType.String;
                param.Value = newEmployee.City;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@vcDepartmentName";
                param.DbType = DbType.String;
                param.Value = newEmployee.DepartmentName;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@djDateofJoin";
                param.DbType = DbType.DateTime;
                param.Value = newEmployee.DateofJoin;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    employeeAdded = true;
            }
            catch (DbException ex)
            {
                //string errormessage;

                //switch (ex.ErrorCode)
                //{
                //    case -2146232060:
                //        errormessage = "Database Does NotExists Or AccessDenied";
                //        break;
                //    default:
                //        errormessage = ex.Message;
                //        break;
                //}
                throw new EmployeeMgmtException(ex.Message);
            }
            return employeeAdded;



        }

        public Employee SearchEmployeesDAL(int searchEmployeeID)
        {
            Employee searchEmployee = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "ProSearchEmployee1";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@iEmployeeID";
                param.DbType = DbType.Int32;
                param.Value = searchEmployeeID;
                command.Parameters.Add(param);

                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchEmployee = new Employee();
                    searchEmployee.EmployeeID = (int)dataTable.Rows[0][0];
                    searchEmployee.EmployeeName = (string)dataTable.Rows[0][1];
                    searchEmployee.City = (string)dataTable.Rows[0][2];
                    searchEmployee.DepartmentName = (string)dataTable.Rows[0][3];
                    searchEmployee.DateofJoin = (DateTime)dataTable.Rows[0][4];

                }
            }
            catch (DbException ex)
            {
                throw new EmployeeMgmtException(ex.Message);
            }
            return searchEmployee;
        }

        public bool UpdateEmployeesDAL(Employee updateEmployee)
        {
            bool employeeUpdated = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "ProUpdateEmployee1";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@iEmployeeID";
                param.DbType = DbType.Int32;
                param.Value = updateEmployee.EmployeeID;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@vcEmployeeName";
                param.DbType = DbType.String;
                param.Value = updateEmployee.EmployeeName;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@vcCity";
                param.DbType = DbType.String;
                param.Value = updateEmployee.City;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@vcDepartmentName";
                param.DbType = DbType.String;
                param.Value = updateEmployee.DepartmentName;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@djDateofJoin";
                param.DbType = DbType.String;
                param.Value = updateEmployee.DateofJoin;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    employeeUpdated = true;
            }
            catch (DbException ex)
            {
                throw new EmployeeMgmtException(ex.Message);
            }
            return employeeUpdated;

        }

        public bool DeleteEmployeesDAL(int deleteEmployeeID)
        {
            bool employeeDeleted = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "ProDeleteEmployee1";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@iEmployeeID";
                param.DbType = DbType.Int32;
                param.Value = deleteEmployeeID;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    employeeDeleted = true;
            }
            catch (DbException ex)
            {
                throw new EmployeeMgmtException(ex.Message);
            }
            return employeeDeleted;

        }

    }
}
