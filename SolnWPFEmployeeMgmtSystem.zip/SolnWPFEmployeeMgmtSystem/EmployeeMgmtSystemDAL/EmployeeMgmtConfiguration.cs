﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace EmployeeMgmtSystemDAL
{
    class EmployeeMgmtConfiguration
    {
        private static string providerName;

        public static string ProviderName
        {
            get { return EmployeeMgmtConfiguration.providerName; }
            set { EmployeeMgmtConfiguration.providerName = value; }
        }
        private static string connectionString;

        public static string ConnectionString
        {
            get { return EmployeeMgmtConfiguration.connectionString; }
            set { EmployeeMgmtConfiguration.connectionString = value; }
        }

        static EmployeeMgmtConfiguration()
        {
            providerName = ConfigurationManager.ConnectionStrings["employeeMgmtConnection"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["employeeMgmtConnection"].ConnectionString;

        }
    }
}

