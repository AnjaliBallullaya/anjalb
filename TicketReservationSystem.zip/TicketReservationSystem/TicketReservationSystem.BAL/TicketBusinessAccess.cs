﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketReservationSystem.Entities;
using TicketReservationSystem.DAL;
using TicketReservationSystem.TicketExceptions;
using System.Text.RegularExpressions;

namespace TicketReservationSystem.BAL
{
    public class TicketBusinessAccess
    {
        #region Validation
        public bool Validate(Ticket ticketObject)
        {
            bool isValid = true;
            //StringBuilder is used to store the errors that might occur during validation
            StringBuilder sb = new StringBuilder();

            //PNRCode should be of type 8876543 (starting with 8) and so on
            if (!Regex.IsMatch(ticketObject.PNR.ToString(), "^[8][0-9]{5}$"))
            {
                sb.Append("Invalid PNR Code\n");
                isValid = false;
            }

            //pnrcode cannot be empty
            if (ticketObject.PNR.ToString() == string.Empty)
            {
                sb.Append("PNR Code cant be empty.\n");
                isValid = false;
            }

            if(ticketObject.JOURNEYDATE < ticketObject.BOOKINGDATE)
            {
                sb.Append("Journey Date cannot be less than Booking Date");
                isValid = false;
            }

            //Source cannot be empty
            if (ticketObject.SOURCE.ToString() == string.Empty)
            {
                sb.Append("Source Cannot be Empty\n");
                isValid = false;
            }
            //Destination cannot be empty
            if (ticketObject.DESTINATION.ToString() == string.Empty)
            {
                sb.Append("Destination Cannot be Empty\n");
                isValid = false;
            }

            //the zone can only be Indian or Pacific
            if (ticketObject.TYPE.ToLower() != "sleeper" && ticketObject.TYPE.ToLower() != "3ac"
                && ticketObject.TYPE.ToLower() != "2ac" && ticketObject.TYPE.ToLower() != "1ac")
            {
                sb.Append("Type can only be sleeper, 2AC, 3AC, 1AC\nTaking Sleeper as default");
                isValid = false;
            }
            

            //Raise exception if invalid data is found
            if (isValid == false)
            {
                throw new MyTicketException(sb.ToString());
            }
            return isValid;

        }
        #endregion

        #region Methods
        //Method to add new Ticket
        public bool AddTicket(Ticket ticketObject)
        {
            bool result = false;
            //checking if the ticket object is valid
            if (Validate(ticketObject))
            {
                //Creating DataAccessLayer class object
                TicketDataAccess ticketData = new TicketDataAccess();
                result = true;

                //Invoking its AddTicket method
                return ticketData.AddTicket(ticketObject);
            }
            return result;
        }

        //Method to dislpay Tickets
        public List<Ticket> DisplayTickets()
        {
            TicketDataAccess ticketData = new TicketDataAccess();
            return ticketData.ViewTickets();
        }

        //Method to view the Ticket Details and Price
        public Ticket SearchTickets(int pnrCode)
        {
            TicketDataAccess ticketData = new TicketDataAccess();
            return ticketData.Search(pnrCode);
        }
        #endregion
    }
}
