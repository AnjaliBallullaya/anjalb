﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using TicketReservationSystem.Entities;

namespace TicketReservationSystem.DAL
{
    class SerializationClass
    {
        public static void SerializeData(List<Ticket> ticketList)
        {
            //serialization of the data into the dat file
            FileStream fileStream = new FileStream("d:\\TicketData.dat", FileMode.Append);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            foreach (Ticket item in ticketList)
            {
                binaryFormatter.Serialize(fileStream, item);
            }

            fileStream.Close();
        }

        public static void DeSerializeData(FileStream filestream)
        {
            //deserialization of data from dat file
            FileStream fileStream = new FileStream("d:\\TicketData.dat", FileMode.Open);
            List<Ticket> ticketData = new List<Ticket>();
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            while (fileStream.Position != fileStream.Length)
            {
                Ticket ticketDes = binaryFormatter.Deserialize(fileStream) as Ticket;
                ticketData.Add(ticketDes);
            }
            fileStream.Close();

        }
    }
}
