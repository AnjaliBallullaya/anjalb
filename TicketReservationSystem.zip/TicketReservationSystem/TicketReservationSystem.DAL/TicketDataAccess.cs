﻿using System;
using System.Collections.Generic;
using TicketReservationSystem.Entities;

namespace TicketReservationSystem.DAL
{
    [Serializable]
    public class TicketDataAccess
    {
        #region Fields
        //List created to store the Ticket data of type <Ticket>
        static List<Ticket> ticketList = new List<Ticket>();
        #endregion

        #region Methods
        //Add Ticekts to the List
        public bool AddTicket(Ticket ticketObject)
        {
            bool result = false;
            try
            {
                ticketList.Add(ticketObject);
                result = true;
                //Data Serialized into file TicketData.dat
                SerializationClass.SerializeData(ticketList);
            }
            catch (Exception)
            {
                result = false;
            }
            return result;
        }

        //View all Tickets present in the List
        public List<Ticket> ViewTickets()
        {
            return ticketList;
        }

        //Search the Ticket from the List
        public Ticket Search(int pnrCode)
        {
            Ticket ticketObj = null;
            foreach (Ticket item in ticketList)
            {
                if (item.PNR == pnrCode)
                {
                    ticketObj = item;
                    break;
                }

            }
            return ticketObj;
        }
        #endregion
    }
}
