﻿using System;

namespace TicketReservationSystem.TicketExceptions
{
    public class MyTicketException : ApplicationException
    {
        public MyTicketException() : base()
        {

        }

        public MyTicketException(string message) : base(message) 
        {

        }

        public MyTicketException(string message, Exception innerException) : base(message,innerException)
        {

        }
    }
}
