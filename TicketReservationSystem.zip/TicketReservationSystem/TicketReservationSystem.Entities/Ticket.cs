﻿using System;

namespace TicketReservationSystem.Entities
{
    [Serializable]
    public class Ticket
    {
        #region Fields
        private int _pnrcode;
        private string _source;
        private string _destination;
        private DateTime _journeyDate;
        private DateTime _bookingDate;
        private string _type;
        private int _price;
        private int _numberOfTickets;
        #endregion

        #region Properties
        public int PNR
        {
            get
            { return _pnrcode; }
            set
            { _pnrcode = value; }
        }
        public string SOURCE
        {
            get
            { return _source; }
            set
            { _source = value; }
        }
        public string DESTINATION
        {
            get
            { return _destination; }
            set
            { _destination = value; }
        }
        public DateTime JOURNEYDATE
        {
            get
            { return _journeyDate; }
            set
            { _journeyDate = value; }
        }
        public DateTime BOOKINGDATE
        {
            get
            { return _bookingDate; }
            set
            { _bookingDate = value; }
        }
        public string TYPE
        {
            get
            { return _type; }
            set
            { _type = value; }
        }
        public int NUMBEROFTICKETS
        {
            get
            { return _numberOfTickets; }
            set
            { _numberOfTickets = value; }
        }

        public int PRICE
        {
            get
            { return _price; }
            set
            { _price = value; }
        }

        #endregion

        #region Constructors
        public Ticket()
        {

        }
        #endregion
    }
}
