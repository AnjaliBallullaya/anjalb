﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketReservationSystem.BAL;
using TicketReservationSystem.Entities;
using TicketReservationSystem.TicketExceptions;

namespace TicketReservationSystem.PL
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Main
            try
            {
                int choice = 0;
                do
                {
                    PrintMenu();
                    Console.WriteLine("Enter your choice");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            AddTicket();
                            break;
                        case 2:
                            ViewAllTickets();
                            break;
                        case 3:
                            SearchTicketDetails();
                            break;
                        default:
                            Console.WriteLine("Exiting the console");
                            return;
                    }
                }

                while (choice != 4);
            }
            catch (MyTicketException ex) //specific exception
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex) //generalized exception
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex) //General exception
            {
                Console.WriteLine(ex.Message);
            }
        }
        #endregion

        #region Methods
        //Method to print the items in the menu
        static void PrintMenu()
        {
            Console.WriteLine("--------------------------------------------");
            Console.WriteLine("Welcome to Ticket Reservation System");
            Console.WriteLine("--------------------------------------------");
            Console.WriteLine("1.Get Ticket Details");
            Console.WriteLine("2.Display Ticket Purchase History");
            Console.WriteLine("3.Search Ticket");
            Console.WriteLine("4.Exit");
            Console.WriteLine("--------------------------------------------");
        }

        static void AddTicket()
        {
            try
            {
                //Create object of Ticket Entity
                Ticket ticketObj = new Ticket();

                //Store all Ticket information
                Console.WriteLine("Enter PNR Code");
                ticketObj.PNR = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Source");
                ticketObj.SOURCE = Console.ReadLine();
                Console.WriteLine("Enter the Destination");
                ticketObj.DESTINATION = Console.ReadLine();
                Console.WriteLine("Enter the Journey Date");
                ticketObj.JOURNEYDATE = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter Type");
                ticketObj.TYPE = Console.ReadLine();
                string type = ticketObj.TYPE.ToLower();
                Console.WriteLine("Enter Number of Tickets");
                ticketObj.NUMBEROFTICKETS = Convert.ToInt32(Console.ReadLine());
                int number = ticketObj.NUMBEROFTICKETS;
                if (type.Equals("1ac"))
                    ticketObj.PRICE = number * 1500;
                else if (type.Equals("2ac"))
                    ticketObj.PRICE = number * 1175;
                else if (type.Equals("3ac"))
                    ticketObj.PRICE = number * 950;
                else
                    ticketObj.PRICE = number * 500;
                ticketObj.BOOKINGDATE = DateTime.Today;

                //Create obj of Business Layer
                TicketBusinessAccess ticketBusiness = new TicketBusinessAccess();
                bool result = ticketBusiness.AddTicket(ticketObj);

                //Print Message if data added successfully
                if (result)
                {
                    Console.WriteLine("Ticket Added Successfully");
                }
            }
            catch(MyTicketException ex)
            {
                Console.WriteLine(ex.Message);
            }

            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void ViewAllTickets()
        {
            try
            {
                TicketBusinessAccess ticketBusiness = new TicketBusinessAccess();
                List<Ticket> ticketList = ticketBusiness.DisplayTickets();
                foreach (Ticket item in ticketList)
                {
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("PNR Code: {0}", item.PNR);
                    Console.WriteLine("Source: {0}", item.SOURCE);
                    Console.WriteLine("Destination: {0}", item.DESTINATION);
                    Console.WriteLine("Date Of Booking: {0}", item.BOOKINGDATE.ToString("dd/MM/yyyy"));
                    Console.WriteLine("Date Of Journey: {0}", item.JOURNEYDATE.ToString("dd/MM/yyyy"));
                    Console.WriteLine("Type: {0}", item.TYPE);
                    Console.WriteLine("Price: {0}", item.PRICE);
                    Console.WriteLine("Number Of Tickets: {0}", item.NUMBEROFTICKETS);

                }
                Console.WriteLine();
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Method to view performance of the salesman
        static void SearchTicketDetails()
        {
            try
            {
                Console.WriteLine("--------------------------------------------");
                Console.WriteLine("Enter PNRCode");
                int pnrCode = Convert.ToInt32(Console.ReadLine());

                TicketBusinessAccess ticketBusiness = new TicketBusinessAccess();
                Ticket ticket = ticketBusiness.SearchTickets(pnrCode);

                if (ticket != null)
                {

                    Console.WriteLine("Source: {0}", ticket.SOURCE);
                    Console.WriteLine("Destination: {0}", ticket.DESTINATION);
                    Console.WriteLine("Date Of Booking: {0}", ticket.BOOKINGDATE.ToString("dd/MM/yyyy"));
                    Console.WriteLine("Date Of Journey: {0}", ticket.JOURNEYDATE.ToString("dd/MM/yyyy"));
                    Console.WriteLine("Type: {0}", ticket.TYPE);
                    Console.WriteLine("Price: {0}", ticket.PRICE);
                    Console.WriteLine("Number Of Tickets: {0}", ticket.NUMBEROFTICKETS);

                }
                else
                {
                    Console.WriteLine("No Ticket found.");
                }
            }
            catch (MyTicketException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        #endregion
    }
}

