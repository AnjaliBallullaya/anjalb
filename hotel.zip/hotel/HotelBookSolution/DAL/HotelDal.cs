﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityLayer;
using System.Data.Common;
using System.Data;
using HotelException;

namespace DAL
{
    public class HotelDal
    {
        public static bool AddCustomer(Customer Obj)
        {
            bool added = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "AddCustomer ";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@CustomerName";
                param.DbType = DbType.String;
                param.Value = Obj.CustomerName;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@Address";
                param.DbType = DbType.String;
                param.Value = Obj.Address;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@IdDoc";
                param.DbType = DbType.String;
                param.Value = Obj.Document;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    added = true;
            }
            catch (HotException ex)
            {
                throw ex;
            }
            return added;
        }

        public static bool BookRoom(Booking Obj)
        {
            bool Booked = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "Bookroom";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@CustomerName";
                param.DbType = DbType.String;
                param.Value = Obj.CustName;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@HotelID";
                param.DbType = DbType.Int32;
                param.Value = Obj.HotId;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@DateIn";
                param.DbType = DbType.DateTime;
                param.Value = Obj.InDate;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@DateOut";
                param.DbType = DbType.DateTime;
                param.Value = Obj.OutDate;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@RoomType";
                param.DbType = DbType.String;
                param.Value = Obj.RoomType;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    Booked = true;
            }
            catch (HotException ex)
            {
                throw ex;
            }
            return Booked;
        }
    }
}
