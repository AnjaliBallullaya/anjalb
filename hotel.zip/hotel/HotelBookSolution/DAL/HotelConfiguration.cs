﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    class HotelConfiguration
    {
        private static string providerName;

        public static string ProviderName
        {
            get { return HotelConfiguration.providerName; }
            set { HotelConfiguration.providerName = value; }
        }
        private static string connectionString;

        public static string ConnectionString
        {
            get { return HotelConfiguration.connectionString; }
            set { HotelConfiguration.connectionString = value; }
        }

        static HotelConfiguration()
        {
            providerName = ConfigurationManager.ConnectionStrings["HotelConnection"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["HotelConnection"].ConnectionString;

        }
    }
}
