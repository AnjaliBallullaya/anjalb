﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLayer
{
    public class Booking
    {
        public  string City { get; set; }

        public int HotId { get; set; }

        public DateTime InDate { get; set; }

        public DateTime OutDate { get; set; }

        public string RoomType { get; set; }

        public string CustName { get; set; }

    }
}
