﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HotelException
{
    public class HotException:ApplicationException
    {
        public HotException() : base()
        {

        }

        public HotException(string message) : base(message)
        {

        }

        public HotException(string message, Exception innerException) : base(message, innerException)
        {

        }
    }
}
