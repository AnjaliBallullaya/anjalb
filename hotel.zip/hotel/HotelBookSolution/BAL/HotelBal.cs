﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityLayer;
using DAL;
using HotelException;

namespace BAL
{
    public class HotelBal
    {

        public static bool AddCustomer(Customer Obj)
        {
            bool added = false;

            try
            {
                added = HotelDal.AddCustomer(Obj);
            }
            catch(HotException ex)
            {
                throw ex;
            }
            return added;
        }

        public static bool BookRoom(Booking Obj)
        {
            bool booked = false;

            try
            {
                booked = HotelDal.BookRoom(Obj);
            }
            catch (HotException ex)
            {
                throw ex;
            }
            return booked;
        }

        public static Double FareCalc(Double datedif, int roomfare)
        {
            Double fare = 0;
            fare = datedif * roomfare;
            return fare;
        }
    }
}
