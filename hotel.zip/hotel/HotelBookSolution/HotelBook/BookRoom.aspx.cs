﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EntityLayer;
using BAL;

namespace HotelBook
{
    public partial class BookRoom : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void ButtonReserve_Click(object sender, EventArgs e)
        {
            Customer Cust = new Customer();
            Cust.CustomerName = TextBoxName.Text;
            Cust.Address = TextBoxAddress.Text;
            Cust.Document = DropDownListDoc.SelectedItem.Text;

            bool added = false;

            added = HotelBal.AddCustomer(Cust);

            if(added)
                Label12.Text = "CUSTOMER ADDED";
            else
                Label12.Text = "CUSTOMER NOT ADDED";

            Booking book = new Booking();

            book.HotId =Int32.Parse(DropDownListCity.SelectedItem.Value);
            book.InDate = DateTime.Parse(TextBoxIN.Text);
            book.OutDate = DateTime.Parse(TextBoxOUT.Text);
            book.RoomType = DropDownListRoomType.Text;
            book.CustName= TextBoxName.Text;

            Double datediff = (book.OutDate-book.InDate).TotalDays;
            int roomfare= Convert.ToInt32(DropDownListRoomType.SelectedItem.Value);
            Double fare;

            bool booked = false;

            booked = HotelBal.BookRoom(book);
            if (booked)
            {
                Label12.Text = "Room Booked";
                fare = HotelBal.FareCalc(datediff, roomfare);
                Label11.Text = fare.ToString();
            }

            else
                Label12.Text = "Room NOT Booked";

        }
    }
}