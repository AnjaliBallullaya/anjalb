﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HotelBook
{
    public partial class LOGIN : System.Web.UI.Page
    {
        string _username = "Akshay";
        string _password = "akshay";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (AdminNameText.Text.Equals(_username) && AdminPassText.Text.Equals(_password))
            {
                Response.Redirect("BookRoom.aspx");
            }
            else
               Label5.Text = "Credentials do not match";
        }
    }
}