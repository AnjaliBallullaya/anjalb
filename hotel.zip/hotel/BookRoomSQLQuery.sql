use raod

create table Customer (CustomerID int primary key identity(2000,1),
						CustomerName varchar(30) not null unique,
						Address varchar(30) not null,
						IdDoc varchar(30));  

create table Booking (BookingID int primary key identity(5000,1),
						HotelID int ,
						CustomerID int FOREIGN KEY REFERENCES Customer(CustomerID),
						DateIn Datetime ,
						DateOut Datetime,
						RoomType varchar(30));

create procedure AddCustomer 
(
@CustomerName varchar(30),
@Address varchar(30),
@IdDoc varchar(30)  
)
as
insert into Customer Values(@CustomerName,@Address,@IdDoc)
return

create procedure Bookroom 
(
@CustomerName varchar(30),
@HotelID int ,
@DateIn Datetime ,
@DateOut Datetime,
@RoomType varchar(30)
)
as
insert into Booking Values(@HotelID,(select CustomerID from Customer where CustomerName=@CustomerName),@DateIn,@DateOut,@RoomType);
return

select *from Booking

select *from Customer
