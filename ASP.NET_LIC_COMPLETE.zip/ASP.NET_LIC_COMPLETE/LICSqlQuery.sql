CREATE DATABASE LIC
GO

USE LIC
GO

CREATE TABLE Policy (	PolicyID int primary key,
						PolicyName varchar(50),
						Duration int,
						PremiumAmount numeric,
						MaturityAmount numeric
					);
GO


create table Branch ( BranchID int Primary key,
						BranchName varchar(50),
						BranchAddress varchar(100)
					  );
GO


CREATE TABLE Customer ( CustomerID int primary key identity(1,1),
						CustomerName varchar(50) unique,
						BirthDate datetime ,
						CustomerAddress varchar(100)
					 );
GO

Alter table Customer Add LogPassword varchar(50);

CREATE TABLE CustomerPolicy ( CustomerID int,
							  PolicyID int ,
							  BranchID int 
							);
GO

drop table CustomerPolicy



select *from Customer;

USE LIC
GO

Create Procedure [dbo].[SearchCustomer]
	(
	@PCustomerName varchar(50),
	@PCustomerPassword	varchar(50)
	)
	
AS
		select *from Customer where CustomerName=@PCustomerName and LogPassword=@PCustomerPassword;
	RETURN

create procedure [dbo].[GetAllPolicy]
AS
select PolicyName from Policy;
return

create procedure [dbo].[GetPolicyID]
(
	@PolicyName varchar(50)
)
AS
select policyID from Policy where PolicyName=@PolicyName
return

create procedure [dbo].[GetAllBranch]
AS
select BranchName from Branch;
return

create procedure [dbo].[GetBranchID]
(
	@BranchName varchar(50)
)
AS
select BranchID from Branch where BranchName=@BranchName
return

create procedure  [dbo].[SearchCustomerDataEntry]
(
	@CustomerName varchar(50)
)
as
select CustomerID, CustomerAddress, BirthDate from Customer where CustomerName=@CustomerName;
return

insert into Customer (CustomerName,BirthDate,CustomerAddress,LogPassword) values('Akshay','12/22/2017','Vitla','AkshayPass')
insert into Customer (CustomerName,BirthDate,CustomerAddress,LogPassword) values('Vinay','12/25/2017','Puttur','VinayPass')


insert into Policy values('1000','p0',5,10000,15000);
insert into Policy values('1001','p1',10,10000,25000);
insert into Policy values('1002','p2',15,10000,30000);
insert into Policy values('1003','p3',20,10000,50000);

insert into Branch values('2000','b0','Vitla');
insert into Branch values('2001','b1','Puttur');
insert into Branch values('2002','b2','Bangalore');
insert into Branch values('2003','b3','Kalkere');

ALTER Procedure [dbo].[SearchCustInCSTDAL]
(
	@CustomerID int,
	@PolicyID int,
	@BranchID int
	
)
as
select * from CustomerPolicy where CustomerID=@CustomerID AND BranchID=@BranchID AND PolicyID=@PolicyID ;
return

ALTER Procedure [dbo].[AddNewCustInCST]
(
	@CustomerID int,
	@PolicyID int,
	@BranchID int
	
)
as

insert into CustomerPolicy values(@CustomerID , @PolicyID, @BranchID);
return

select *from CustomerPolicy;

delete from CustomerPolicy;

create procedure NewRegister
(
@CustName varchar(50),
@CustAddress varchar(100),
@CustDob datetime,
@LogPass varchar(50)
)
as
insert into Customer values ( @CustName, @CustDob, @CustAddress,@LogPass)
return


select *from Customer;

select *from CustomerPolicy;

create procedure GetNewCustID
(
@CustName varchar(50)
)
as
select CustomerID from Customer where CustomerName=@CustName;
return
