﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using LICBAL;
using ENTITY;
using System.Web.Security;

namespace LIC
{
    public partial class LoginPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void ButtonLogin_Click(object sender, EventArgs e)
        {

            
            string LogName = TextBoxCustomerName.Text;
            string Password = TextBoxPassword.Text;

            bool CorrectLog = ClassLICBAL.SearchCustomer(LogName, Password);

            if (CorrectLog)
            {
                if (true)
                {
                    FormsAuthentication.RedirectFromLoginPage(TextBoxCustomerName.Text, false);
                }
                Response.Redirect("DataEntryPage.aspx?" + TextBoxCustomerName.Text);
            }

            else
            {
                Label3.Text = "Please do enter a valid UserName and Password";
              
            }
                
        }

        protected void ButtonNewReg_Click(object sender, EventArgs e)
        {
            Response.Redirect("RegisterNew.aspx");
           
        }
    }
}