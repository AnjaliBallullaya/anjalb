﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ENTITY;
using LICBAL;

namespace LIC
{
    public partial class RegisterNew : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            ClassCustomer NewCustObj = new ClassCustomer();
            try
            {
                NewCustObj.CustomerName = TextBoxName.Text;
                NewCustObj.CustomerAddress = TextBoxAddress.Text;
                NewCustObj.BirthDate = Convert.ToDateTime(Calendar1.SelectedDate);
                NewCustObj.LoginPass = TextBoxPassword001.Text;

                bool Registered = false;

                Registered = ClassLICBAL.NewRegisterBAL(NewCustObj);

                if (Registered)
                {
                    Label7.Text = "New Customer has been Succesfully Registered. Congratulations............!!!";
                    TextBoxNewCustID.Text = Convert.ToInt32(ClassLICBAL.GetNewCustIDBAL(NewCustObj)).ToString();

                }
            }

            catch(Exception EX)
            {
                Label7.Text = EX.Message.ToString();
            }
        }

        protected void ButtonLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("LoginPage.aspx");
        }
    }
}