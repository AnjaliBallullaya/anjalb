﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using ENTITY;


namespace LICDAL
{
    public class ClassLICDAL
    {
        public static bool SearchCustomer(string LogName, string Password)
        {
            bool CorrectLog = false;

            try
            {
                DbCommand command = ClassLICDataConnection.CreateCommand();
                command.CommandText = "SearchCustomer";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@PCustomerName";
                param.DbType = DbType.String;
                param.Value = LogName;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@PCustomerPassword";
                param.DbType = DbType.String;
                param.Value = Password;
                command.Parameters.Add(param);

                DataTable dataTable = ClassLICDataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    CorrectLog = true;
                }
            }
            catch
            {
                //throw new ClassLICException(ex.Message);
            }

            return CorrectLog;
        }

        public static List<string> GetAllPolicyDAL()
        {
            DbCommand command = ClassLICDataConnection.CreateCommand();
            command.CommandText = "GetAllPolicy";

            List<string> PloicyList = null;

            DataTable dataTable = ClassLICDataConnection.ExecuteSelectCommand(command);
            if (dataTable.Rows.Count > 0)
            {
                PloicyList = new List<string>();
                for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                {
                    string PolicyOne;
                    PolicyOne = (string)dataTable.Rows[rowCounter][0];
                    PloicyList.Add(PolicyOne);
                }
            }

            return PloicyList;


        }

        public static int GetPolicyID(string PolicyName)
        {
            DbCommand command = ClassLICDataConnection.CreateCommand();
            command.CommandText = "GetPolicyID";

            DbParameter param = command.CreateParameter();
            param.ParameterName = "@PolicyName";
            param.DbType = DbType.String;
            param.Value = PolicyName;
            command.Parameters.Add(param);

            int PolicyID = 0;

            DataTable dataTable = ClassLICDataConnection.ExecuteSelectCommand(command);
            if (dataTable.Rows.Count > 0)
            {

                PolicyID = (int)dataTable.Rows[0][0];

            }

            return PolicyID;

        }

        public static List<string> GetAllBranchDAL()
        {
            DbCommand command = ClassLICDataConnection.CreateCommand();
            command.CommandText = "GetAllBranch";

            List<string> BranchList = null;

            DataTable dataTable = ClassLICDataConnection.ExecuteSelectCommand(command);
            if (dataTable.Rows.Count > 0)
            {
                BranchList = new List<string>();
                for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                {
                    string BranchOne;
                    BranchOne = (string)dataTable.Rows[rowCounter][0];
                    BranchList.Add(BranchOne);
                }
            }

            return BranchList;
        }

        public static int GetBranchID(string BranchName)
        {
            DbCommand command = ClassLICDataConnection.CreateCommand();
            command.CommandText = "GetBranchID";

            DbParameter param = command.CreateParameter();
            param.ParameterName = "@BranchName";
            param.DbType = DbType.String;
            param.Value = BranchName;
            command.Parameters.Add(param);

            int BranchID = 0;

            DataTable dataTable = ClassLICDataConnection.ExecuteSelectCommand(command);
            if (dataTable.Rows.Count > 0)
            {

                BranchID = (int)dataTable.Rows[0][0];

            }

            return BranchID;

        }

        public static ClassCustomer GetCustomerInfoDAL(string CustomerName)
        {
            ClassCustomer customer = null;

            DbCommand command = ClassLICDataConnection.CreateCommand();
            command.CommandText = "SearchCustomerDataEntry";

            DbParameter param = command.CreateParameter();
            param.ParameterName = "@CustomerName";
            param.DbType = DbType.String;
            param.Value = CustomerName;
            command.Parameters.Add(param);

            DataTable dataTable = ClassLICDataConnection.ExecuteSelectCommand(command);
            if (dataTable.Rows.Count > 0)
            {
                customer = new ClassCustomer();
                customer.CustomerID = (int)dataTable.Rows[0][0];
                customer.CustomerAddress = (string)dataTable.Rows[0][1];
                customer.BirthDate = (DateTime)dataTable.Rows[0][2];

            }

            return customer;
        }

        public static bool SearchCustInCSTDAL(ClassCustomerPolicy CS)
        {
            bool Exists = false;

            DbCommand command = ClassLICDataConnection.CreateCommand();
            command.CommandText = "SearchCustInCSTDAL";

            DbParameter param = command.CreateParameter();
            param.ParameterName = "@CustomerID";
            param.DbType = DbType.Int32;
            param.Value = CS.CustomerID;
            command.Parameters.Add(param);

            param = command.CreateParameter();
            param.ParameterName = "@PolicyID";
            param.DbType = DbType.Int32;
            param.Value = CS.PolicyID;
            command.Parameters.Add(param);

            param = command.CreateParameter();
            param.ParameterName = "@BranchID";
            param.DbType = DbType.Int32;
            param.Value = CS.BranchID;
            command.Parameters.Add(param);

            DataTable dataTable = ClassLICDataConnection.ExecuteSelectCommand(command);
            int rc = dataTable.Rows.Count;
            if (dataTable.Rows.Count > 0)
            {
                Exists = true;
            }
            return Exists;
        }

        public static bool AddNewCustPolicyDAL(ClassCustomerPolicy CS)
        {
            bool added = false;
            DbCommand command = ClassLICDataConnection.CreateCommand();
            command.CommandText = "AddNewCustInCST";

            DbParameter param = command.CreateParameter();
            param.ParameterName = "@CustomerID";
            param.DbType = DbType.Int32;
            param.Value = CS.CustomerID;
            command.Parameters.Add(param);

            param = command.CreateParameter();
            param.ParameterName = "@PolicyID";
            param.DbType = DbType.Int32;
            param.Value = CS.PolicyID;
            command.Parameters.Add(param);

            param = command.CreateParameter();
            param.ParameterName = "@BranchID";
            param.DbType = DbType.String;
            param.Value = CS.BranchID;
            command.Parameters.Add(param);

            int rowsaffected = ClassLICDataConnection.ExecuteNonQueryCommand(command);
            if (rowsaffected > 0)
            {
                added = true;
            }
            return added;
        }

        public static bool NewRegisterDAL(ClassCustomer NewCustObj)
        {
            bool Registered = false;

            DbCommand command = ClassLICDataConnection.CreateCommand();
            command.CommandText = "NewRegister";

            DbParameter param = command.CreateParameter();
            param.ParameterName = "@CustName";
            param.DbType = DbType.String;
            param.Value = NewCustObj.CustomerName;
            command.Parameters.Add(param);

            param = command.CreateParameter();
            param.ParameterName = "@CustAddress";
            param.DbType = DbType.String;
            param.Value = NewCustObj.CustomerAddress;
            command.Parameters.Add(param);

            param = command.CreateParameter();
            param.ParameterName = "@CustDob";
            param.DbType = DbType.DateTime;
            param.Value = NewCustObj.BirthDate;
            command.Parameters.Add(param);

            param = command.CreateParameter();
            param.ParameterName = "@LogPass";
            param.DbType = DbType.String;
            param.Value = NewCustObj.LoginPass;
            command.Parameters.Add(param);

            int rowsaffected = ClassLICDataConnection.ExecuteNonQueryCommand(command);
            if (rowsaffected > 0)
            {
                Registered = true;
            }

            return Registered;
        }

        public static int NewCustIDDAL(ClassCustomer NewCustObj)
        {
            int CustID=0;
            DbCommand command = ClassLICDataConnection.CreateCommand();
            command.CommandText = "GetNewCustID";

            DbParameter param = command.CreateParameter();
            param.ParameterName = "@CustName";
            param.DbType = DbType.String;
            param.Value = NewCustObj.CustomerName;
            command.Parameters.Add(param);

            DataTable dataTable = ClassLICDataConnection.ExecuteSelectCommand(command);
            if (dataTable.Rows.Count > 0)
            {

                CustID = (int)dataTable.Rows[0][0];

            }
            return CustID;

        }
    }
}
