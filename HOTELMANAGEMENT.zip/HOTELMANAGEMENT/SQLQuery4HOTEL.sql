CREATE DATABASE HOTEL
USE HOTEL

CREATE TABLE Customer
(
	CUSTOMERID int primary key identity(2000,1),
	CUSTOMERNAME varchar(30) not null,
	CUSTOMERADDRESS varchar(50) not null,
	IDDOC varchar(30)  
);

CREATE TABLE Booking
(
	BOOKINGID int primary key identity(5000,1),
	HOTELID int not null,
	CUSTOMERID int foreign key references Customer(CUSTOMERID),
	DATEIN DateTime,
	DATEOUT DateTime ,
	ROOMTYPE varchar(30)
);

Create table Documents
(
	DocId int primary key identity(1,1),
	Doc varchar(30)
)


insert into Documents values ('AADHAR'),('PAN'),('VOTERID');

CREATE PROCEDURE getIdDocList
as
SELECT Doc from Documents;

CREATE TABLE ROOMS
(
	RId int primary key identity(1,1),
	RoomType varchar(30)
)

insert into ROOMS values ('AC'),('NONAC');

CREATE PROCEDURE getroomtypeList
as
SELECT ROOMTYPE from ROOMS;

CREATE PROCEDURE insertCustomer
(
	@CUSTOMERNAME varchar(30),
	@CUSTOMERADDRESS varchar(50),
	@IDDOC varchar(30)

)
as
INSERT INTO Customer (CUSTOMERNAME,CUSTOMERADDRESS,IDDOC)VALUES(@CUSTOMERNAME,@CUSTOMERADDRESS,@IDDOC);

CREATE PROCEDURE BookingProcedure
(
	
	@HOTELID int,
	@CUSTOMERNAME varchar(30),
	@DATEIN DateTime,
	@DATEOUT DateTime ,
	@ROOMTYPE varchar(30)
)
as
insert into Booking VALUES(@HOTELID,(SELECT CUSTOMERID FROM Customer where CUSTOMERNAME=@CUSTOMERNAME),@DATEIN,@DATEOUT,@ROOMTYPE);

DELETE FROM Customer


