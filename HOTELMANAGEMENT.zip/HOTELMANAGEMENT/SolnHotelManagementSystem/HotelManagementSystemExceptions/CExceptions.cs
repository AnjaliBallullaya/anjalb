﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagementSystemExceptions
{
    public class CExceptions:ApplicationException
    {
        public CExceptions()
        {

        }

        public CExceptions(string message): base (message)
        {

        }

        public CExceptions(string message, Exception InnerException): base(message, InnerException)
        {

        }
    }
}
