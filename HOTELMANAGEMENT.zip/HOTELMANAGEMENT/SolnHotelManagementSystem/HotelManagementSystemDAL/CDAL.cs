﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelManagementSystemEntities;
using HotelManagementSystemExceptions;
using System.Data.Common;
using System.Data;

namespace HotelManagementSystemDAL
{
    public class CDAL
    {
        public List<String> getIdDocListDAL()
        {
            List<String> iddoclist = null;
            try
            {
                DbCommand command = CDataConnection.CreateCommand();
                command.CommandText = "getIdDocList";



                DataTable dataTable = CDataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    iddoclist = new List<string>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        String cust = "";
                        cust = (string)dataTable.Rows[rowCounter][0];
                        iddoclist.Add(cust);
                    }
                }
            }
            catch (CExceptions ex)
            {

                throw new CExceptions(ex.Message);
            }
            return iddoclist;
        }


        public List<string> getRoomTypeListDAL()
        {
            List<string> cList = null;
            try
            {
                DbCommand command = CDataConnection.CreateCommand();
                command.CommandText = "getroomtypeList";



                DataTable dataTable = CDataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    cList = new List<string>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        string c = "";
                        c = (string)dataTable.Rows[rowCounter][0];
                        cList.Add(c);
                    }

                }
            }
            catch (DbException ex)
            {
                throw new CExceptions(ex.Message);
            }
            return cList;
        }

        public bool AddCustomerDAL(CCustEntities adobj)
        {
            bool custAdded = false;
            try
            {
                DbCommand command = CDataConnection.CreateCommand();
                command.CommandText = "insertCustomer";

                DbParameter param = command.CreateParameter();

                param = command.CreateParameter();
                param.ParameterName = "@CUSTOMERNAME";
                param.DbType = DbType.String;
                param.Value = adobj.CUSTOMERNAME;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@CUSTOMERADDRESS";
                param.DbType = DbType.String;
                param.Value = adobj.ADDRESS;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@IDDOC";
                param.DbType = DbType.String;
                param.Value = adobj.IDDOC;
                command.Parameters.Add(param);

                int affectedRows = CDataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    custAdded = true;
            }
            catch (DbException ex)
            {

                throw ex;
            }
            return custAdded;
        }

        public bool AddBookingDAL(CBookingEntities adobj)
        {
            bool bookAdded = false;
            try
            {
                DbCommand command = CDataConnection.CreateCommand();
                command.CommandText = "BookingProcedure";

                DbParameter param = command.CreateParameter();

                param = command.CreateParameter();
                param.ParameterName = "@HOTELID";
                param.DbType = DbType.String;
                param.Value = adobj.HOTELID;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@CUSTOMERNAME";
                param.DbType = DbType.String;
                param.Value = adobj.CUSTOMERNAME;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@DATEIN";
                param.DbType = DbType.DateTime;
                param.Value = adobj.DATEIN;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@DATEOUT";
                param.DbType = DbType.DateTime;
                param.Value = adobj.DATEOUT;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ROOMTYPE";
                param.DbType = DbType.String;
                param.Value = adobj.ROOMTYPE;
                command.Parameters.Add(param);

                int affectedRows = CDataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    bookAdded = true;
            }
            catch (DbException ex)
            {

                throw ex;
            }
            return bookAdded;
        }
   


    }
}
