﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagementSystemDAL
{
    class CHotelConfiguration
    {
       
            private static string providerName;

            public static string ProviderName
            {
                get { return CHotelConfiguration.providerName; }
                set { CHotelConfiguration.providerName = value; }
            }
            private static string connectionString;

            public static string ConnectionString
            {
                get { return CHotelConfiguration.connectionString; }
                set { CHotelConfiguration.connectionString = value; }
            }

        static CHotelConfiguration()
            {
                providerName = ConfigurationManager.ConnectionStrings["HotelCon"].ProviderName;
                connectionString = ConfigurationManager.ConnectionStrings["HotelCon"].ConnectionString;
            }

        }
    }

