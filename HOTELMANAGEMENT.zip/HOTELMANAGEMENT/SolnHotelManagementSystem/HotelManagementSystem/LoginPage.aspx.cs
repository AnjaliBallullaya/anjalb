﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HotelManagementSystem
{
    public partial class LoginPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            if ((txtusername.Text == "anjali") && (txtpassword.Text == "213"))
            {
                Response.Redirect("Register.aspx");
            }
            else
            {
                lblerror.Text = "Invalid User";
            }
        }

        protected void btnreset_Click(object sender, EventArgs e)
        {
            txtusername.Text = String.Empty;
            txtpassword.Text = String.Empty;
        }
    }
}