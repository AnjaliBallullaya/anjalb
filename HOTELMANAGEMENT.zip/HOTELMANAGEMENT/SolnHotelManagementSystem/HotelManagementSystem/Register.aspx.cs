﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HotelManagementSystemBAL;
using HotelManagementSystemEntities;
using HotelManagementSystemExceptions;

namespace HotelManagementSystem
{
    public partial class Register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmessage.Text = "";
            if (!Page.IsPostBack)
            {
                try
                {
                    List<string> clist = null;
                    clist = CBAL.getIdDocListBAL();
                    ddliddoc.Items.Add("Select IDDOC");
                    ddliddoc.AppendDataBoundItems = true;
                    ddliddoc.DataSource = clist;


                    ddliddoc.DataBind();

                    List<string> blist = null;
                    blist = CBAL.getRoomTypeListBAL();
                    ddlroomtype.Items.Add("Select RoomType");
                    ddlroomtype.AppendDataBoundItems = true;
                    ddlroomtype.DataSource = blist;


                   
                    ddlroomtype.DataBind();
                }
                   catch(CExceptions ex)
                    {
                    throw ex;
                   }
                }

        }

            //protected void btnbook_Click(object sender, EventArgs e)
            //{
            //    try
            //    {
            //        CFormEntities newcust = new CFormEntities();

            //        newcust.CITY = Convert.ToInt32(ddlcity.SelectedItem.Value);
            //        newcust.CUSTOMERNAME = txtcustname.Text;
            //        newcust.ADDRESS = txtaddress.Text;
            //        newcust.IDDOC = ddliddoc.SelectedItem.Value;
            //        newcust.FAIR = Convert.ToInt32(ddlroomtype.SelectedItem.Value);
            //        newcust.DATEIN = DateTime.Parse(TextBox1.Text);
            //        newcust.DATEOUT = DateTime.Parse(TextBox2.Text);
            //        bool custAdded = CBAL.AddCustomerBAL(newcust);
            //        if (custAdded)
            //        {
            //            lblmessage.Text = "Rooms Booked Successfully";

            //        }

            //        else
            //            lblmessage.Text = "Rooms not Booked";

            //    }
            //    catch (CExceptions ex)
            //    {
            //        Console.WriteLine(ex.Message);
            //    }

            //}
        }
    }
