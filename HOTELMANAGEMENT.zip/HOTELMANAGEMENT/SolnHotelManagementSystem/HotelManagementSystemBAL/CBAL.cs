﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelManagementSystemDAL;
using HotelManagementSystemEntities;
using HotelManagementSystemExceptions;

namespace HotelManagementSystemBAL
{
    public class CBAL
    {
        public static List<string> getIdDocListBAL()
        {
            List<string> clist = null;
            try
            {
                CDAL CDal = new CDAL();
                clist = CDal.getIdDocListDAL();
            }
            catch (CExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return clist;
         }

        public static List<string> getRoomTypeListBAL()
        {
            List<string> blist = null;
            try
            {
                CDAL BDal = new CDAL();
                blist = BDal.getRoomTypeListDAL();
            }
            catch (CExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blist;
        }

        //public static bool AddCustomerBAL(CFormEntities newcust)
        //{
        //    bool custAdded = false;
        //    try
        //    {
        //        CDAL custDAL = new CDAL();
        //        custAdded = custDAL.AddCustomerDAL(newcust);
        //    }
        //    catch (CExceptions ex)
        //    {
        //        throw;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return custAdded;

        //}
    }
}
