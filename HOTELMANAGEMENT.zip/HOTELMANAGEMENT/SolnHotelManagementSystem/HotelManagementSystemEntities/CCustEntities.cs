﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagementSystemEntities
{
    public class CCustEntities
    {
        public int CUSTOMERID { get; set; }
        public string CUSTOMERNAME { get; set; }
        public string ADDRESS { get; set; }
        public string IDDOC { get; set; }
    }
}
