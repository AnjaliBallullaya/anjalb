﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagementSystemEntities
{
    public class CBookingEntities
    {

        public string  CUSTOMERNAME { get; set; }
        public int HOTELID { get; set; }
       
        public DateTime DATEIN { get; set; }
        public DateTime DATEOUT { get; set; }
        public string ROOMTYPE { get; set; }

    }
}
