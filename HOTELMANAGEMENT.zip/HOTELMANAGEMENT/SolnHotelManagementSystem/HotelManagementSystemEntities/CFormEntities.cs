﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagementSystemEntities
{
    public class CFormEntities
    {
        public int CITY { get; set; }
        public string CUSTOMERNAME { get; set; }
        public string ADDRESS { get; set; }
        public string IDDOC { get; set; }
        public int FAIR { get; set; }
        public DateTime DATEIN { get; set; }
        public DateTime DATEOUT { get; set; }

    }
}
