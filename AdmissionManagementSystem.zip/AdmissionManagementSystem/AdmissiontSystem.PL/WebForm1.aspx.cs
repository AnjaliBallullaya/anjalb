﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AdmissionSystem.Entities;
using AdmissionSystem.BAL;

namespace AdmissiontSystem.PL
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                int sid = Convert.ToInt32(TextBox1.Text);
                string pass = TextBox2.Text;
                StudLogin studLogin = AdmissionBAL.SearchLoginBL(sid, pass);


                if (sid == studLogin.STUDENTID && pass == studLogin.PASSWORD)
                    Response.Redirect("RegisterUser.aspx");
                else
                    Label7.Text = "Invalid Details";
            }
            catch (Exception)
            {

                Label7.Text = "Invalid details";
            }
            
        }
    }
}