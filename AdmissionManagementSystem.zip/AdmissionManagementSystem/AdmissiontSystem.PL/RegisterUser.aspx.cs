﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AdmissionSystem.BAL;
using AdmissionSystem.Entities;

namespace AdmissiontSystem.PL
{
    public partial class RegisterUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                List<Course> courseList = AdmissionBAL.GetCourse();
                List<Institute> instituteList = AdmissionBAL.GetInstitute();
                foreach (Course item in courseList)
                {
                    ddlCourse.Items.Add(item.COURSENAME);
                    ddlCourse.SelectedItem.Value = item.COURSEID.ToString();
                }
                foreach (Institute item in instituteList)
                {
                    ddlInstitute.Items.Add(item.INSTITUTENAME);
                    ddlInstitute.SelectedItem.Value = item.INSTITUTEID.ToString();
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string name = txtSname.Text;
            DateTime dob = calDOB.SelectedDate;
            string instituteName = ddlInstitute.SelectedItem.Value;
            string courseName = ddlCourse.SelectedItem.Value;
            Student student = new Student();
            Admission admission = new Admission();
            student.STUDENTNAME = name;
            student.DOB = dob;
            admission.COURSEID = Convert.ToInt32(courseName);
            admission.ADMISSIONDATE = DateTime.Today;
            admission.INSTITUTEID = Convert.ToInt32(instituteName);
            try
            {
                bool added = AdmissionBAL.AddStudent(student,admission);
                Label12.Text = "Added";
            }
            catch (Exception ex)
            {
                Label12.Text = ex.Message;
            }
        }
    }
}