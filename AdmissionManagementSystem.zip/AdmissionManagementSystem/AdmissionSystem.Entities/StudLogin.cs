﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdmissionSystem.Entities
{
    public class StudLogin
    {
        public int STUDENTID { get; set; }
        public string PASSWORD { get; set; }
    }
}
