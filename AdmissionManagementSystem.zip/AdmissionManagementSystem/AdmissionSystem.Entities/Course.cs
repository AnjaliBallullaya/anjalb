﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdmissionSystem.Entities
{
    public class Course
    {
        public int COURSEID { get; set; }
        public string COURSENAME { get; set; }
    }
}
