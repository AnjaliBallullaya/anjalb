﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdmissionSystem.Entities
{
    public class Institute
    {
        public int INSTITUTEID { get; set; }
        public string INSTITUTENAME { get; set; }
        public string CITY { get; set; }
    }
}
