﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InstituteEnt;
using InstituteException;
using InstituteDal;

namespace InstituteBal
{
    public class CInstituteBAL
    {
        public static bool AddStudent(CAdmission obj)
        {
            bool studentAdded = false;
            try
            {
                InstituteDAL admDAL = new InstituteDAL();
                studentAdded = admDAL.AddStudent(obj);

            }
            catch (CInstituteException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return studentAdded;

        }

        public static List<CCourse> GetCourse()
        {
            List<CCourse> courseList = null;
            try
            {
                InstituteDAL admDal = new InstituteDAL();
                courseList = admDal.GetCourseDAL();
            }
            catch (CInstituteException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return courseList;
        }

        public static List<CInstitute> GetInstitute()
        {
            List<CInstitute> instituteList = null;
            try
            {
                InstituteDAL admDal = new InstituteDAL();
                instituteList = admDal.GetInstituteDAL();
            }
            catch (CInstituteException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return instituteList;
        }
        public static bool AddStudentTab(CStudent obj)
        {
            bool studentAdded = false;
            try
            {
                InstituteDAL admDAL = new InstituteDAL();
                studentAdded = admDAL.AddStudentTab(obj);

            }
            catch (CInstituteException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return studentAdded;

        }
    }
}
