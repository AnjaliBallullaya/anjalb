﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace InstitutePL
{
    public partial class Login1 : System.Web.UI.Page
    {
        string _username = "Anusha";
        string _password = "123456";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtboxUsername.Text.Equals(_username) && txtboxPassword.Text.Equals(_password))
            {
                Response.Redirect("RegisterStudent.aspx");
            }
            else
                ErrorLabel.Text = "Credentials do not match";
        }
    }
}