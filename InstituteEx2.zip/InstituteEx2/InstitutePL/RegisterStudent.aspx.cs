﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using InstituteBal;
using InstituteEnt;

namespace InstitutePL
{
    public partial class RegisterStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                List<CCourse> courseList = CInstituteBAL.GetCourse();
                List<CInstitute> instituteList = CInstituteBAL.GetInstitute();
                foreach (CCourse item in courseList)
                {
                    ddlCourse.Items.Add(item.COURSENAME);
                    //ddlCourse.SelectedItem.Value = item.COURSEID.ToString();
                }
                foreach (CInstitute item in instituteList)
                {
                    ddlInstitute.Items.Add(item.CITY);
                   // ddlInstitute.SelectedItem.Value = item.INSTITUTEID.ToString();
                }
            }

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            CAdmission obj = new CAdmission();
            obj.STUDENTNAME = TextBox1.Text;
            obj.INSTITUTENAME = ddlInstitute.SelectedItem.Value;
            obj.COURSENAME=ddlCourse.SelectedItem.Value;
            obj.DOB = Calendar1.SelectedDate;

            CStudent Studentobj = new CStudent();
            Studentobj.STUDENTNAME = obj.STUDENTNAME;
            Studentobj.DOB = obj.DOB;



            try
            {
                bool sadded= CInstituteBAL.AddStudentTab(Studentobj);
                bool added = CInstituteBAL.AddStudent(obj);


                if(added)
                Label7.Text = "Added";
            }
            catch (Exception ex)
            {
                Label7.Text = ex.Message;
            }
       }  }
}