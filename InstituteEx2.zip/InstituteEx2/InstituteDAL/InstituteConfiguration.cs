﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace InstituteDal
{
    class InstituteConfiguration
    {
        private static string providerName;

        public static string ProviderName
        {
            get { return InstituteConfiguration.providerName; }
            set { InstituteConfiguration.providerName = value; }
        }
        private static string connectionString;

        public static string ConnectionString
        {
            get { return InstituteConfiguration.connectionString; }
            set { InstituteConfiguration.connectionString = value; }
        }

        static InstituteConfiguration()
        {
            providerName = ConfigurationManager.ConnectionStrings["InstituteConnection"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["InstituteConnection"].ConnectionString;

        }
    }
}
