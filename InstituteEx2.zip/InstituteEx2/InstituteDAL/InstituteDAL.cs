﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using InstituteEnt;
using InstituteException;

namespace InstituteDal
{
    public class InstituteDAL
    {
        public bool AddStudent(CAdmission obj)
        {
            bool customerAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "Register";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@StudentName";
                param.DbType = DbType.String;
                param.Value = obj.STUDENTNAME;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@DOB";
                param.DbType = DbType.DateTime;
                param.Value = obj.DOB;
                command.Parameters.Add(param);


                //param = command.CreateParameter();
                //param.ParameterName = "@AdmissionDate";
                //param.DbType = DbType.String;
                //param.Value = obj.ADMISSIONDATE;
                //command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@CourseName";
                param.DbType = DbType.String;
                param.Value = obj.COURSENAME;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@InstituteName";
                param.DbType = DbType.String;
                param.Value =obj.INSTITUTENAME;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    customerAdded = true;
            }
            catch (DbException ex)
            {
                throw ex;
                //string errormessage;

                //switch (ex.ErrorCode)
                //{
                //    //case -2146232060:
                //    //    errormessage = "Database Does NotExists Or AccessDenied";
                //       // break;
                //    //default:
                //    //   errormessage = ex.Message;
                //    //    break;
                //}
                //throw new CInstituteException(errormessage);
            }
            return customerAdded;
        }

        public List<CCourse> GetCourseDAL()
        {
            List<CCourse> courseList = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "GetAllCourses";
                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    courseList = new List<CCourse>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        CCourse course = new CCourse();
                        course.COURSENAME = (string)dataTable.Rows[rowCounter][0];
                        courseList.Add(course);
                    }

                }
            }
            catch (DbException ex)
            {
                throw new CInstituteException(ex.Message);
            }
            return courseList;
        }

        public List<CInstitute> GetInstituteDAL()
        {
            List<CInstitute> instituteList = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "GetAllInstitutes";
                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    instituteList = new List<CInstitute>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        CInstitute institute = new CInstitute();
                        institute.CITY = (string)dataTable.Rows[rowCounter][0];
                        instituteList.Add(institute);
                    }

                }
            }
            catch (DbException ex)
            {
                throw new CInstituteException(ex.Message);
            }
            return instituteList;
        }
        public bool AddStudentTab(CStudent obj)
        {
            bool customerAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "StudentReg";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@studentName";
                param.DbType = DbType.String;
                param.Value = obj.STUDENTNAME;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@dob";
                param.DbType = DbType.DateTime;
                param.Value = obj.DOB;
                command.Parameters.Add(param);
                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    customerAdded = true;
            }
            catch (DbException ex)
            {
                throw ex;
                //string errormessage;

                //switch (ex.ErrorCode)
                //{
                //    //case -2146232060:
                //    //    errormessage = "Database Does NotExists Or AccessDenied";
                //       // break;
                //    //default:
                //    //   errormessage = ex.Message;
                //    //    break;
                //}
                //throw new CInstituteException(errormessage);
            }
            return customerAdded;
        }
    }
}
