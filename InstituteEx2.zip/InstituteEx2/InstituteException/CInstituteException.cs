﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstituteException
{
    public class CInstituteException:ApplicationException
    {
        public CInstituteException() : base()
        {

        }

        public CInstituteException(string message) : base(message)
        {

        }

        public CInstituteException(string message, Exception innerException) : base(message, innerException)
        {

        }
    }
}
