﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstituteEnt
{
    public class CCourse
    {
        public int COURSEID { get; set; }
        public string COURSENAME { get; set; }
    }
}
