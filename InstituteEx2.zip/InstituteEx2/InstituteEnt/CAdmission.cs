﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstituteEnt
{
   public class CAdmission
    {
        public string STUDENTNAME { get; set; }
        public string COURSENAME { get; set; }
        public string INSTITUTENAME { get; set; }
        public DateTime DOB { get; set; }
    }
}
