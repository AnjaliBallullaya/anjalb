﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstituteEnt
{
    public class CInstitute
    {
        public int INSTITUTEID { get; set; }
        public string CITY { get; set; }
    }
}
