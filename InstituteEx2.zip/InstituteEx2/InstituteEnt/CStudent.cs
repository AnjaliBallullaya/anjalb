﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstituteEnt
{
    public class CStudent
    {
        public int STUDENTID { get; set; }
        public string STUDENTNAME { get; set; }
        public DateTime DOB { get; set; }
    }
}
