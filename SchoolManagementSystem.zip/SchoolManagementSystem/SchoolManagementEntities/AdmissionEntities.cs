﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolManagementEntities
{
    class AdmissionEntities
    {
        public int AdmissionID { get; set; }
        public DateTime AdmissionDate { get; set; }
    }
}
