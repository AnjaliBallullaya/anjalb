﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolManagementEntities
{
    public class InstituteEntities
    {
        public int InstituteID { get; set; }
        public string City { get; set; }
    }
}
