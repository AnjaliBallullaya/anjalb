﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SchoolException;
using SchoolManagementEntities;
using DataAccessLayer;


namespace BusinessAccessLayer
{
    public class SchoolBAL
    {
        public static List<InstituteEntities> GetAllInstitute()
        {
            List<InstituteEntities> institutelist = null;
            try
            {
                SchoolDAL sDAL = new SchoolDAL();
                institutelist = sDAL.GetAllInstitute();
            }
            catch(Exceptions ex)
            {
                throw ex;
            }
            return institutelist;
        }
    }
}
