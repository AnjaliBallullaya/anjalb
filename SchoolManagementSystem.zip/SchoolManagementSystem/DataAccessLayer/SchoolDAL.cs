﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SchoolException;
using SchoolManagementEntities;
using System.Data.Common;
using System.Data;

namespace DataAccessLayer
{
   public class SchoolDAL
    {
        public List<InstituteEntities> GetAllInstitute()
        {
            List<InstituteEntities> institutelist = null;
                try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspGetAllInstitute";

                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    institutelist = new List<InstituteEntities>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        InstituteEntities Institute = new InstituteEntities();
                        Institute.InstituteID = (int)dataTable.Rows[rowCounter][0];
                        Institute.City = (string)dataTable.Rows[rowCounter][1];
                        institutelist.Add(Institute);
                    }
                }

            }
            catch (DbException ex)
            {
                throw new Exceptions(ex.Message);
            }
            return institutelist;
        }
    }
}
