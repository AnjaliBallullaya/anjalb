﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;
using System.Data;
using System.Configuration;

namespace DataAccessLayer
{
    class SchoolConfiguration
    {
        private static string providerName;

        public static string ProviderName
        {
            get { return SchoolConfiguration.providerName; }
            set { SchoolConfiguration.providerName = value; }
        }
        private static string connectionString;

        public static string ConnectionString
        {
            get { return SchoolConfiguration.connectionString; }
            set { SchoolConfiguration.connectionString = value; }
        }

        static SchoolConfiguration()
        {
            providerName = ConfigurationManager.ConnectionStrings["SchCon"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["SchCon"].ConnectionString;
        }
    }
}
