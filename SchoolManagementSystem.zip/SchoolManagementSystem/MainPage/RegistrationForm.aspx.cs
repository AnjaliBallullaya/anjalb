﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SchoolException;
using SchoolManagementEntities;
using BusinessAccessLayer;

namespace MainPage
{
    public partial class RegistrationForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          
            if(!Page.IsPostBack)
            {
                try
                {
                    List<InstituteEntities> institutelist = SchoolBAL.GetAllInstitute();
                    DropDownList1.Items.Add("Select a Institute");
                    DropDownList1.AppendDataBoundItems = true;

                    DropDownList1.DataSource = institutelist;

                    DropDownList1.DataTextField = "City";
                    DropDownList1.DataValueField = "InstituteID";

                    DropDownList1.DataBind();
                }
                catch(Exceptions ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
    }
}